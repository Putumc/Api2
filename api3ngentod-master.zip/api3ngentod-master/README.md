<p align="center">
<a href="#"><img title="Rest-Api" src="https://img.shields.io/badge/Rest Api Free-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/inirey"><img title="Author" src="https://img.shields.io/badge/AUTHOR-SEKHA-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://www.codefactor.io/repository/github/inirey/RESTAPI/overview/master"><img title="Rating" src="https://www.codefactor.io/repository/github/inirey/RESTAPI/badge/master"></a>
</p>
<p align="center">
<a href="https://github.com/inirey/followers"><img title="Followers" src="https://img.shields.io/github/followers/inirey?color=blue&style=flat-square"></a>
<a href="https://github.com/inirey/RESTAPI/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/inirey/RESTAPI?color=red&style=flat-square"></a>
<a href="https://github.com/inirey/RESTAPI/network/members"><img title="Forks" src="https://img.shields.io/github/forks/inirey/RESTAPI?color=red&style=flat-square"></a>
<a href="https://github.com/inirey/RESTAPI/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/inirey/RESTAPI?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Finirey%2FRESTAPI&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
